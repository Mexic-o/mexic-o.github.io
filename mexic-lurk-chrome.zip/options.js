(async () => {
  let state = await UI.send("getState");

  const savedToast = UI.$("#saved");
  let toastTimer;
  const toast = text => {
    savedToast.textContent = text || "Enregistré";
    savedToast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => savedToast.classList.remove("show"), 1400);
  };

  const showError = (id, text) => {
    const el = UI.$(id);
    el.textContent = text || "";
    el.classList.toggle("hidden", !text);
  };

  /* ----- Compte ----- */
  const renderAccount = () => {
    UI.$("#who").textContent = state.connected ? "Connecté : " + state.userLogin : "Pas connecté";
    UI.$("#connect").classList.toggle("hidden", state.connected);
    UI.$("#disconnect").classList.toggle("hidden", !state.connected);
  };

  /* Connexion par code : on ouvre twitch.tv/activate, la personne clique « Activer ». */
  let cancelled = false;
  const connect = async withChat => {
    cancelled = false;
    const box = UI.$("#device");
    const dev = await Twitch.startDevice(withChat);
    UI.$("#device-code").textContent = dev.user_code;
    box.classList.remove("hidden");
    UI.$("#connect").disabled = true;
    let twitchTab = await browser.tabs.create({ url: dev.verification_uri, active: true });
    UI.$("#device-open").onclick = async () => {
      twitchTab = await browser.tabs.create({ url: dev.verification_uri, active: true });
    };
    UI.$("#device-cancel").onclick = () => { cancelled = true; };
    try {
      await Twitch.waitForDevice(dev, () => cancelled);
    } finally {
      box.classList.add("hidden");
      UI.$("#connect").disabled = false;
    }
    try { await browser.tabs.remove(twitchTab.id); } catch (e) { /* déjà fermé */ }
    try {
      const me = await browser.tabs.getCurrent();
      if (me) await browser.tabs.update(me.id, { active: true });
    } catch (e) { /* ok */ }
    state = await UI.send("loggedIn");
  };

  UI.$("#connect").onclick = async () => {
    showError("#account-error", "");
    try {
      await connect(state.settings.reminderEnabled);
      renderAccount();
      toast("Compte connecté");
    } catch (e) {
      showError("#account-error", "Connexion impossible : " + e.message);
    }
  };

  UI.$("#disconnect").onclick = async () => {
    await Twitch.logout();
    state = await UI.send("loggedOut");
    renderAccount();
    toast("Déconnecté");
  };

  /* ----- Réglages ----- */
  const s = state.settings;
  document.querySelectorAll('input[name="mode"]').forEach(r => { r.checked = r.value === s.mode; });
  UI.$("#quietEnabled").checked = s.quietEnabled;
  UI.$("#quietStart").value = s.quietStart;
  UI.$("#quietEnd").value = s.quietEnd;
  UI.$("#volume").value = s.volume;
  UI.$("#volume-value").textContent = s.volume + " %";
  UI.$("#reminderEnabled").checked = s.reminderEnabled;
  UI.$("#reminderInterval").value = String(s.reminderInterval);
  UI.$("#reminderMessage").value = s.reminderMessage;
  UI.$("#youtubeEnabled").checked = s.youtubeEnabled && state.youtubeConfigured;
  UI.$("#youtubeEnabled").disabled = !state.youtubeConfigured;
  UI.$("#yt-soon").classList.toggle("hidden", state.youtubeConfigured);

  const refreshDisabled = () => {
    UI.$("#quiet-fields").classList.toggle("disabled", !UI.$("#quietEnabled").checked);
    UI.$("#reminder-fields").classList.toggle("disabled", !UI.$("#reminderEnabled").checked);
  };

  const save = async patch => {
    await Store.saveSettings(patch);
    state = await UI.send("settingsChanged");
    refreshDisabled();
    toast();
  };

  document.querySelectorAll('input[name="mode"]').forEach(r => {
    r.onchange = () => save({ mode: r.value });
  });
  document.querySelectorAll('input[name="lurkMode"]').forEach(r => {
    r.checked = r.value === s.lurkMode;
    r.onchange = () => save({ lurkMode: r.value });
  });
  UI.$("#quietEnabled").onchange = e => save({ quietEnabled: e.target.checked });
  UI.$("#quietStart").onchange = e => save({ quietStart: e.target.value || "01:00" });
  UI.$("#quietEnd").onchange = e => save({ quietEnd: e.target.value || "17:00" });
  UI.$("#volume").oninput = e => { UI.$("#volume-value").textContent = e.target.value + " %"; };
  UI.$("#volume").onchange = e => save({ volume: Number(e.target.value) });
  UI.$("#reminderInterval").onchange = e => save({ reminderInterval: Number(e.target.value) });
  UI.$("#reminderMessage").onchange = e => save({ reminderMessage: e.target.value.trim() || "Je lurk encore ♥" });
  UI.$("#youtubeEnabled").onchange = e => save({ youtubeEnabled: e.target.checked });

  UI.$("#reminderEnabled").onchange = async e => {
    showError("#reminder-error", "");
    const on = e.target.checked;
    if (on) {
      if (!state.connected) {
        e.target.checked = false;
        showError("#reminder-error", "Connecte d'abord ton compte Twitch.");
        return;
      }
      if (!state.hasChatScope) {
        try {
          await connect(true);
        } catch (err) {
          e.target.checked = false;
          showError("#reminder-error", "Autorisation non donnée : " + err.message);
          return;
        }
      }
    }
    await save({ reminderEnabled: on });
  };

  renderAccount();
  refreshDisabled();
})();
