/* Point d'entrée de l'arrière-plan (service worker) pour Chrome, Edge, Opera et Brave. */
importScripts("lib/browser-shim.js", "config.js", "lib/store.js", "lib/twitch.js", "background.js");
