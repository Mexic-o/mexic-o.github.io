/* Mexic Lurk – script d'arrière-plan.
 * Rien ne s'ouvre jamais sans un choix de la personne :
 *  - une seule fenêtre d'alerte par live (Lurk / Live / Je passe mon tour) ;
 *  - le lurk est un vrai lecteur Twitch visible (popout officiel, 460 × 340), son bas mais pas coupé ;
 *  - le rappel de lurk est optionnel et n'envoie un message que si la personne clique « Envoyer ».
 */

const SUB_CHECK_EVERY = 30 * 60 * 1000;
const YT_MAX_AGE = 48 * 3600 * 1000;

/* ---------- Utilitaires ---------- */

function minutesOf(hhmm) {
  const [h, m] = String(hhmm || "0:0").split(":").map(Number);
  return (h || 0) * 60 + (m || 0);
}

function inQuietHours(s) {
  if (!s.quietEnabled) return false;
  const now = new Date();
  const cur = now.getHours() * 60 + now.getMinutes();
  const start = minutesOf(s.quietStart);
  const end = minutesOf(s.quietEnd);
  if (start === end) return false;
  return start < end ? (cur >= start && cur < end) : (cur >= start || cur < end);
}

/* Position en bas à droite de la fenêtre principale du navigateur
 * (dans Chrome/Edge/Opera, l'arrière-plan n'a pas accès à la taille de l'écran). */
async function corner(size) {
  const margin = 16;
  try {
    const wins = await browser.windows.getAll({ windowTypes: ["normal"] });
    const w = wins.find(x => x.focused) || wins[0];
    if (w && w.width && w.height) {
      return {
        width: size.width,
        height: size.height,
        left: Math.max(w.left, w.left + w.width - size.width - margin),
        top: Math.max(w.top, w.top + w.height - size.height - margin),
        areaTop: w.top
      };
    }
  } catch (e) { /* fenêtre inconnue */ }
  return { width: size.width, height: size.height };
}

function box(c) {
  const out = { width: c.width, height: c.height };
  if (c.left != null) { out.left = c.left; out.top = c.top; }
  return out;
}

async function windowAlive(id) {
  if (id == null) return false;
  try { await browser.windows.get(id); return true; } catch (e) { return false; }
}

async function tabAlive(id) {
  if (id == null) return false;
  try { await browser.tabs.get(id); return true; } catch (e) { return false; }
}

async function closeWindow(id) {
  if (id == null) return;
  try { await browser.windows.remove(id); } catch (e) { /* déjà fermée */ }
}

function playerUrl(volume) {
  const params = new URLSearchParams({
    channel: MEXIC.CHANNEL_LOGIN,
    parent: "twitch.tv",
    player: "popout",
    muted: "false",
    volume: (Math.max(1, Math.min(100, volume)) / 100).toFixed(2),
    quality: "360p30"
  });
  return "https://player.twitch.tv/?" + params.toString();
}

/* Ouvre une adresse dans une fenêtre normale du navigateur (pas dans un mini-lecteur). */
async function openInMainWindow(url) {
  const wins = await browser.windows.getAll({ windowTypes: ["normal"] });
  const target = wins.find(w => w.focused) || wins[0];
  if (target) {
    await browser.tabs.create({ windowId: target.id, url });
    await browser.windows.update(target.id, { focused: true });
  } else {
    await browser.windows.create({ url });
  }
}

/* ---------- Badge ---------- */

async function updateBadge() {
  const { token, live } = await Store.get(["token", "live"]);
  if (!token) {
    await browser.action.setBadgeText({ text: "!" });
    await browser.action.setBadgeBackgroundColor({ color: "#f2a541" });
    await browser.action.setTitle({ title: "Mexic Lurk – connecte ton compte Twitch" });
    return;
  }
  if (live) {
    await browser.action.setBadgeText({ text: "LIVE" });
    await browser.action.setBadgeBackgroundColor({ color: "#e5384c" });
    if (browser.action.setBadgeTextColor) await browser.action.setBadgeTextColor({ color: "#ffffff" });
    await browser.action.setTitle({ title: MEXIC.CHANNEL_NAME + " est en live" });
  } else {
    await browser.action.setBadgeText({ text: "" });
    await browser.action.setTitle({ title: "Mexic Lurk" });
  }
}

/* ---------- Abonnement ---------- */

async function checkSubscription(force) {
  const { subCheckedAt } = await Store.get("subCheckedAt");
  if (!force && subCheckedAt && Date.now() - subCheckedAt < SUB_CHECK_EVERY) return;
  let sub;
  try { sub = await Twitch.isSubscribed(); } catch (e) { return; }
  const patch = { subCheckedAt: Date.now() };
  if (sub === true) {
    patch.subscribed = true;
    patch.everSubscribed = true;
    patch.resubDismissed = false;
  } else if (sub === false) {
    patch.subscribed = false;
  }
  await Store.set(patch);
}

async function resubVisible() {
  const { subscribed, everSubscribed, resubDismissed } =
    await Store.get(["subscribed", "everSubscribed", "resubDismissed"]);
  return subscribed === false && everSubscribed === true && !resubDismissed;
}

/* ---------- Live ---------- */

async function poll() {
  const { token } = await Store.get("token");
  if (!token) { await updateBadge(); return; }

  let stream;
  try {
    stream = await Twitch.currentStream();
  } catch (e) {
    await updateBadge();
    return;
  }

  const { live: previous } = await Store.get("live");
  const live = stream ? {
    id: stream.id,
    title: stream.title,
    game: stream.game_name,
    startedAt: stream.started_at,
    thumbnail: stream.thumbnail_url
  } : null;
  await Store.set({ live });
  await updateBadge();

  if (!live) {
    if (previous) await browser.alarms.clear("reminder");
    await showPendingYouTube();
    return;
  }

  await checkSubscription(!previous || previous.id !== live.id);

  const { alertedStreamId, lurkTabId } = await Store.get(["alertedStreamId", "lurkTabId"]);
  if (alertedStreamId === live.id) { await showPendingYouTube(); return; }

  const s = await Store.settings();
  // Mode « badge seulement » ou heures calmes : seul le badge LIVE s'affiche.
  if (s.mode !== "window" || inQuietHours(s)) return;

  await Store.set({ alertedStreamId: live.id });
  if (await tabAlive(lurkTabId)) return; // déjà en lurk
  await openAlertWindow();
}

async function openAlertWindow() {
  const { alertWindowId } = await Store.get("alertWindowId");
  if (await windowAlive(alertWindowId)) return;
  const win = await browser.windows.create(Object.assign({
    type: "popup",
    url: browser.runtime.getURL("alert.html")
  }, box(await corner(MEXIC.ALERT_SIZE))));
  await Store.set({ alertWindowId: win.id });
}

/* Mode « vidéo + chat » : la fenêtre du chat Twitch (popout officiel) s'ouvre juste au-dessus du lecteur,
 * pour que la personne soit connectée au chat comme sur la page de la chaîne. */
async function openLurkChat() {
  const s = await Store.settings();
  if (s.lurkMode !== "chat") return;
  const { lurkChatTabId, lurkChatWindowId } = await Store.get(["lurkChatTabId", "lurkChatWindowId"]);
  if (await tabAlive(lurkChatTabId)) {
    try { await browser.windows.update(lurkChatWindowId, { focused: true }); } catch (e) { /* ok */ }
    return;
  }
  const player = await corner(MEXIC.PLAYER_SIZE);
  const chatBox = { width: MEXIC.CHAT_SIZE.width, height: MEXIC.CHAT_SIZE.height };
  if (player.left != null) {
    chatBox.left = player.left;
    chatBox.top = Math.max(player.areaTop || 0, player.top - MEXIC.CHAT_SIZE.height - 8);
  }
  const win = await browser.windows.create(Object.assign({ type: "popup", url: MEXIC.chatUrl }, chatBox));
  await Store.set({ lurkChatTabId: win.tabs[0].id, lurkChatWindowId: win.id });
}

async function startLurk(fromTab) {
  const s = await Store.settings();
  const url = playerUrl(s.volume);
  let tabId, windowId;

  if (fromTab) {
    // La fenêtre d'alerte se transforme en mini-lecteur.
    tabId = fromTab.id;
    windowId = fromTab.windowId;
    await browser.tabs.update(tabId, { url });
    try { await browser.windows.update(windowId, box(await corner(MEXIC.PLAYER_SIZE))); } catch (e) { /* taille gérée par le système */ }
    await Store.set({ alertWindowId: null });
  } else {
    const { lurkTabId, lurkWindowId } = await Store.get(["lurkTabId", "lurkWindowId"]);
    if (await tabAlive(lurkTabId)) {
      await openLurkChat();
      await browser.windows.update(lurkWindowId, { focused: true });
      return;
    }
    const win = await browser.windows.create(Object.assign({ type: "popup", url }, box(await corner(MEXIC.PLAYER_SIZE))));
    tabId = win.tabs[0].id;
    windowId = win.id;
  }

  await Store.set({ lurkTabId: tabId, lurkWindowId: windowId, lurkStartedAt: Date.now() });
  await openLurkChat();
  try { await browser.windows.update(windowId, { focused: true }); } catch (e) { /* ok */ }
  await scheduleReminder();
}

async function watchLive(fromTab) {
  await openInMainWindow(MEXIC.twitchUrl);
  if (fromTab) await closeWindow(fromTab.windowId);
}

/* ---------- Rappel de lurk (optionnel) ---------- */

async function hasChatScope() {
  const { scopes } = await Store.get("scopes");
  return (scopes || []).includes(MEXIC.SCOPE_CHAT);
}

async function scheduleReminder() {
  await browser.alarms.clear("reminder");
  const s = await Store.settings();
  const { lurkTabId } = await Store.get("lurkTabId");
  if (!s.reminderEnabled || !(await hasChatScope()) || !(await tabAlive(lurkTabId))) return;
  const every = Math.max(30, Number(s.reminderInterval) || 60);
  browser.alarms.create("reminder", { delayInMinutes: every, periodInMinutes: every });
}

async function showReminder() {
  const { lurkTabId, live, reminderWindowId } = await Store.get(["lurkTabId", "live", "reminderWindowId"]);
  const s = await Store.settings();
  if (!live || !s.reminderEnabled || !(await tabAlive(lurkTabId))) {
    await browser.alarms.clear("reminder");
    return;
  }
  if (await windowAlive(reminderWindowId)) return;
  const win = await browser.windows.create(Object.assign({
    type: "popup",
    url: browser.runtime.getURL("reminder.html")
  }, box(await corner(MEXIC.REMINDER_SIZE))));
  await Store.set({ reminderWindowId: win.id });
}

/* ---------- YouTube ---------- */

/* Lecture du flux YouTube sans DOMParser (absent du service worker). */
function parseFeed(text) {
  const decode = v => String(v || "")
    .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'").replace(/&#(\d+);/g, (m, n) => String.fromCodePoint(Number(n)))
    .replace(/&amp;/g, "&");
  return (text.match(/<entry>[\s\S]*?<\/entry>/g) || []).map(e => {
    const pick = re => { const m = e.match(re); return m ? m[1] : ""; };
    return {
      videoId: pick(/<yt:videoId>([^<]+)<\/yt:videoId>/),
      title: decode(pick(/<title>([^<]*)<\/title>/)),
      published: Date.parse(pick(/<published>([^<]+)<\/published>/)) || 0,
      thumb: decode(pick(/<media:thumbnail url="([^"]+)"/))
    };
  }).filter(e => e.videoId);
}

async function checkYouTube() {
  const s = await Store.settings();
  if (!MEXIC.YOUTUBE_CHANNEL_ID || !s.youtubeEnabled) return;
  let text;
  try {
    const res = await fetch("https://www.youtube.com/feeds/videos.xml?channel_id=" +
      encodeURIComponent(MEXIC.YOUTUBE_CHANNEL_ID), { cache: "no-store" });
    if (!res.ok) return;
    text = await res.text();
  } catch (e) { return; }

  const entries = parseFeed(text);
  if (!entries.length) return;

  const { ytSeen } = await Store.get("ytSeen");
  if (!ytSeen) {
    // Premier passage : on mémorise sans alerter.
    await Store.set({ ytSeen: entries.map(e => e.videoId).slice(0, 50) });
    return;
  }
  const fresh = entries.filter(e => !ytSeen.includes(e.videoId) && Date.now() - e.published < YT_MAX_AGE);
  await Store.set({ ytSeen: entries.map(e => e.videoId).concat(ytSeen).filter((v, i, a) => a.indexOf(v) === i).slice(0, 50) });
  if (!fresh.length) return;
  fresh.sort((a, b) => b.published - a.published);
  await Store.set({ ytPending: fresh[0], ytLaterUntil: null });
  await showPendingYouTube();
}

async function showPendingYouTube() {
  const { ytPending, ytLaterUntil, ytWindowId, alertWindowId } =
    await Store.get(["ytPending", "ytLaterUntil", "ytWindowId", "alertWindowId"]);
  if (!ytPending) return;
  const s = await Store.settings();
  if (!s.youtubeEnabled) { await Store.set({ ytPending: null }); return; }
  if (ytLaterUntil && Date.now() < ytLaterUntil) return;
  if (inQuietHours(s)) return;
  if (await windowAlive(ytWindowId)) return;
  if (await windowAlive(alertWindowId)) return; // on attend que l'alerte live soit réglée
  const win = await browser.windows.create(Object.assign({
    type: "popup",
    url: browser.runtime.getURL("youtube.html")
  }, box(await corner(MEXIC.ALERT_SIZE))));
  await Store.set({ ytWindowId: win.id, ytLaterUntil: null });
}

function laterTime() {
  const d = new Date();
  const evening = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 20, 0, 0);
  if (evening - d > 30 * 60 * 1000) return evening.getTime();
  return Date.now() + 2 * 3600 * 1000;
}

/* ---------- État pour les pages ---------- */

async function getState() {
  const data = await Store.get(["token", "userLogin", "live", "lurkStartedAt", "ytPending"]);
  return {
    connected: !!data.token,
    userLogin: data.userLogin || null,
    live: data.live || null,
    showResub: data.token ? await resubVisible() : false,
    settings: await Store.settings(),
    hasChatScope: await hasChatScope(),
    youtubeConfigured: !!MEXIC.YOUTUBE_CHANNEL_ID,
    lurkStartedAt: data.lurkStartedAt || null,
    ytPending: data.ytPending || null,
    channelName: MEXIC.CHANNEL_NAME,
    subUrl: MEXIC.subUrl
  };
}

/* ---------- Messages des pages ---------- */

browser.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Chrome/Edge/Opera : la réponse passe par sendResponse.
  handle(msg || {}, sender).then(sendResponse, err => sendResponse({ ok: false, error: String((err && err.message) || err) }));
  return true;
});

async function handle(msg, sender) {
  const tab = sender.tab;
  switch (msg.type) {
    case "getState":
      if (msg.refresh) { await poll(); await checkSubscription(false); }
      return getState();

    case "lurk":
      await startLurk(msg.inPlace ? tab : null);
      return { ok: true };

    case "live":
      await watchLive(msg.inPlace ? tab : null);
      return { ok: true };

    case "skip": {
      const { live } = await Store.get("live");
      if (live) await Store.set({ alertedStreamId: live.id });
      if (tab) await closeWindow(tab.windowId);
      return { ok: true };
    }

    case "resub":
      await openInMainWindow(MEXIC.subUrl);
      if (msg.inPlace && tab) await closeWindow(tab.windowId);
      return { ok: true };

    case "dismissResub":
      await Store.set({ resubDismissed: true });
      return { ok: true };

    case "isLurkTab": {
      const { lurkTabId } = await Store.get("lurkTabId");
      const s = await Store.settings();
      return { lurk: !!tab && tab.id === lurkTabId, volume: s.volume };
    }

    case "openFull":
      await openInMainWindow(MEXIC.twitchUrl);
      if (tab) await closeWindow(tab.windowId);
      return { ok: true };

    case "sendReminder":
      try {
        await Twitch.sendChat(String(msg.message || "").slice(0, 200));
      } catch (e) {
        return { ok: false, error: e.message };
      }
      if (tab) await closeWindow(tab.windowId);
      return { ok: true };

    case "reminderLater":
      if (tab) await closeWindow(tab.windowId);
      return { ok: true };

    case "ytWatch": {
      const { ytPending } = await Store.get("ytPending");
      await Store.set({ ytPending: null });
      if (ytPending) await openInMainWindow("https://www.youtube.com/watch?v=" + ytPending.videoId);
      if (tab) await closeWindow(tab.windowId);
      return { ok: true };
    }

    case "ytMini": {
      const { ytPending } = await Store.get("ytPending");
      await Store.set({ ytPending: null, ytWindowId: null });
      if (ytPending && tab) {
        await browser.tabs.update(tab.id, { url: "https://www.youtube.com/watch?v=" + ytPending.videoId });
        try { await browser.windows.update(tab.windowId, box(await corner({ width: 480, height: 440 }))); } catch (e) { /* ok */ }
      }
      return { ok: true };
    }

    case "ytLater": {
      const until = laterTime();
      await Store.set({ ytLaterUntil: until });
      browser.alarms.create("ytLater", { when: until });
      if (tab) await closeWindow(tab.windowId);
      return { ok: true, until };
    }

    case "loggedIn":
      await Store.set({ subCheckedAt: 0, alertedStreamId: null });
      await poll();
      await checkSubscription(true);
      await scheduleReminder();
      return getState();

    case "loggedOut":
      await browser.alarms.clear("reminder");
      await Store.set({ live: null });
      await updateBadge();
      return getState();

    case "settingsChanged":
      await scheduleReminder();
      await showPendingYouTube();
      return getState();

    default:
      return null;
  }
}

/* ---------- Fenêtres fermées ---------- */

browser.tabs.onRemoved.addListener(async tabId => {
  const { lurkTabId, lurkChatTabId, lurkChatWindowId } =
    await Store.get(["lurkTabId", "lurkChatTabId", "lurkChatWindowId"]);
  if (tabId === lurkTabId) {
    // Lecteur fermé : on ferme aussi le chat du lurk.
    await Store.set({ lurkTabId: null, lurkWindowId: null, lurkStartedAt: null,
      lurkChatTabId: null, lurkChatWindowId: null });
    await browser.alarms.clear("reminder");
    await closeWindow(lurkChatWindowId);
  } else if (tabId === lurkChatTabId) {
    // Chat fermé seul : la vidéo continue.
    await Store.set({ lurkChatTabId: null, lurkChatWindowId: null });
  }
});

browser.windows.onRemoved.addListener(async windowId => {
  const st = await Store.get(["alertWindowId", "ytWindowId", "reminderWindowId", "ytLaterUntil"]);
  const patch = {};
  if (windowId === st.alertWindowId) patch.alertWindowId = null;
  if (windowId === st.reminderWindowId) patch.reminderWindowId = null;
  if (windowId === st.ytWindowId) {
    patch.ytWindowId = null;
    // Fermée avec la croix (sans « Plus tard ») : on ne repropose pas cette vidéo.
    if (!st.ytLaterUntil || st.ytLaterUntil < Date.now()) patch.ytPending = null;
  }
  if (Object.keys(patch).length) await Store.set(patch);
  if (windowId === st.alertWindowId) await showPendingYouTube();
});

/* ---------- Alarmes et démarrage ---------- */

browser.alarms.onAlarm.addListener(async alarm => {
  if (alarm.name === "poll") await poll();
  else if (alarm.name === "youtube") await checkYouTube();
  else if (alarm.name === "reminder") await showReminder();
  else if (alarm.name === "ytLater") await showPendingYouTube();
  else if (alarm.name === "validate") {
    try {
      const token = await Twitch.ensureToken();
      if (!token) { await updateBadge(); return; }
      const info = await Twitch.validate(token);
      if (!info) { await Twitch.forget(); await updateBadge(); }
      else await Store.set({ scopes: info.scopes || [], tokenCheckedAt: Date.now() });
    } catch (e) { /* hors ligne */ }
  }
});

async function ensureAlarms() {
  const names = (await browser.alarms.getAll()).map(a => a.name);
  if (!names.includes("poll")) browser.alarms.create("poll", { delayInMinutes: 1, periodInMinutes: 1 });
  if (!names.includes("validate")) browser.alarms.create("validate", { delayInMinutes: 60, periodInMinutes: 60 });
  if (!names.includes("youtube")) browser.alarms.create("youtube", { delayInMinutes: 2, periodInMinutes: 15 });
}

browser.runtime.onStartup.addListener(async () => {
  // Nouvelle session du navigateur : les anciennes fenêtres n'existent plus.
  await Store.set({ lurkTabId: null, lurkWindowId: null, lurkStartedAt: null,
    lurkChatTabId: null, lurkChatWindowId: null, alertWindowId: null, ytWindowId: null, reminderWindowId: null });
  await browser.alarms.clear("reminder");
  await ensureAlarms();
  await poll();
});

browser.runtime.onInstalled.addListener(async details => {
  await ensureAlarms();
  if (details.reason === "install") {
    await browser.runtime.openOptionsPage();
  }
  await updateBadge();
});

ensureAlarms();
