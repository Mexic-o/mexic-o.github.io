(async () => {
  const state = await UI.send("getState");
  if (state.live) {
    UI.$("#title").textContent = state.live.title || "";
    UI.$("#game").textContent = state.live.game || "";
  }
  UI.wireResub(UI.$("#resub"), state, false);
  UI.$("#resub .close").addEventListener("click", () => setTimeout(UI.fitWindow, 50));
  UI.fitWindow();

  const lock = () => document.querySelectorAll("button").forEach(b => { b.disabled = true; });

  UI.$("#lurk").onclick = () => { lock(); UI.send("lurk", { inPlace: true }); };
  UI.$("#live").onclick = () => { lock(); UI.send("live", { inPlace: true }); };
  UI.$("#skip").onclick = () => { lock(); UI.send("skip"); };
})();
