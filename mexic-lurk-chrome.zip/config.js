/* Réglages fixes de l'extension (à modifier ici uniquement). */
var MEXIC = {
  // Identifiant client de l'application « Mexic notification » (console Twitch, type Publique).
  CLIENT_ID: "66sypsmh5tcm9s5d5z61wx6rjeqafg",

  // Chaîne Twitch suivie.
  CHANNEL_LOGIN: "mexic_original",
  CHANNEL_NAME: "Mexic_Original",

  // Identifiant de la chaîne YouTube (commence par « UC… »). Vide = alertes YouTube désactivées.
  YOUTUBE_CHANNEL_ID: "UCFZEpBjo4Y7z1FBI_n8s4Jg",

  // Permissions demandées à Twitch.
  SCOPE_BASE: ["user:read:subscriptions"],
  SCOPE_CHAT: "user:write:chat",

  // Tailles des fenêtres (le lecteur Twitch doit rester au moins à 400 × 300).
  ALERT_SIZE: { width: 440, height: 400 },
  PLAYER_SIZE: { width: 460, height: 340 },
  CHAT_SIZE: { width: 460, height: 420 },
  REMINDER_SIZE: { width: 440, height: 300 },

  DEFAULT_SETTINGS: {
    mode: "window",          // "window" ou "badge"
    quietEnabled: false,
    quietStart: "01:00",
    quietEnd: "17:00",
    volume: 5,               // en %
    lurkMode: "chat",        // "chat" = vidéo + chat, "video" = vidéo seule
    reminderEnabled: false,  // désactivé par défaut
    reminderInterval: 60,    // minutes
    reminderMessage: "Je lurk encore ♥",
    youtubeEnabled: true
  }
};

MEXIC.twitchUrl = "https://www.twitch.tv/" + MEXIC.CHANNEL_LOGIN;
MEXIC.subUrl = "https://www.twitch.tv/subs/" + MEXIC.CHANNEL_LOGIN;
MEXIC.chatUrl = "https://www.twitch.tv/popout/" + MEXIC.CHANNEL_LOGIN + "/chat?popout=";
