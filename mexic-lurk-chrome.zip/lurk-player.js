/* S'exécute sur player.twitch.tv, mais n'agit QUE dans la fenêtre de lurk ouverte par l'extension.
 * - Si le navigateur a bloqué la lecture avec le son, affiche un bouton « Lancer le lurk » (un clic de la personne).
 * - Petite barre au survol : « Ouvrir en grand » et l'astuce « premier plan ».
 */
(async () => {
  let info;
  try { info = await browser.runtime.sendMessage({ type: "isLurkTab" }); } catch (e) { return; }
  if (!info || !info.lurk) return;

  const volume = Math.max(1, Math.min(100, info.volume || 5)) / 100;

  const h = (tag, props, children) => {
    const el = document.createElement(tag);
    Object.entries(props || {}).forEach(([k, v]) => {
      if (k === "text") el.textContent = v;
      else if (k === "onclick") el.addEventListener("click", v);
      else el.setAttribute(k, v);
    });
    (children || []).forEach(c => el.appendChild(c));
    return el;
  };

  const css = `
    :host { all: initial; }
    .bar { position: fixed; top: 8px; left: 8px; display: flex; gap: 6px; opacity: 0; transition: opacity .2s; pointer-events: auto; font-family: system-ui, sans-serif; }
    .bar.show, .bar:hover, .bar:focus-within { opacity: 1; }
    .bar button, .start { border: none; border-radius: 8px; cursor: pointer; font: 700 13px system-ui, sans-serif; }
    .bar button { min-height: 32px; padding: 0 10px; background: rgba(26,18,12,.88); color: #fbefd9; border: 1px solid #5a4230; }
    .bar button:hover { background: #3a2a1e; }
    .tip { position: fixed; top: 46px; left: 8px; right: 8px; max-width: 340px; padding: 10px 12px; border-radius: 8px; background: rgba(26,18,12,.94); color: #fbefd9; border: 1px solid #5a4230; font: 13px/1.4 system-ui, sans-serif; pointer-events: auto; }
    .start { position: fixed; left: 50%; top: 50%; transform: translate(-50%, -50%); min-height: 48px; padding: 0 20px; background: #7c4dff; color: #fff; font-size: 15px; box-shadow: 0 6px 20px rgba(0,0,0,.5); pointer-events: auto; }
    .start:hover { background: #6a3cf0; }
    button:focus-visible { outline: 2px solid #9ed15a; outline-offset: 2px; }
    [hidden] { display: none !important; }
  `;

  const host = h("div");
  host.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:2147483647;";
  const root = host.attachShadow({ mode: "closed" });
  root.appendChild(h("style", { text: css }));

  const tip = h("div", { class: "tip", role: "note", text:
    "Pour garder le live au-dessus des autres fenêtres : survole la vidéo et utilise le bouton « Image dans l'image » de ton navigateur." });
  tip.hidden = true;

  const bar = h("div", { class: "bar" }, [
    h("button", { type: "button", text: "Ouvrir en grand", onclick: () => browser.runtime.sendMessage({ type: "openFull" }) }),
    h("button", { type: "button", text: "Premier plan", onclick: async () => {
      // Chrome, Edge, Opera et Brave : vraie vidéo flottante, toujours au-dessus des autres fenêtres.
      const v = document.querySelector("video");
      if (v && document.pictureInPictureEnabled) {
        try {
          v.disablePictureInPicture = false;
          if (document.pictureInPictureElement) await document.exitPictureInPicture();
          else await v.requestPictureInPicture();
          return;
        } catch (e) { /* non disponible : on affiche l'astuce */ }
      }
      tip.hidden = !tip.hidden;
    } })
  ]);

  const start = h("button", { type: "button", class: "start", text: "Lancer le lurk (son " + Math.round(volume * 100) + " %)" });
  start.hidden = true;

  root.appendChild(bar);
  root.appendChild(tip);
  root.appendChild(start);
  document.documentElement.appendChild(host);

  // La barre apparaît quand la souris bouge, puis s'efface.
  let hideTimer;
  const showBar = () => {
    bar.classList.add("show");
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => bar.classList.remove("show"), 2500);
  };
  document.addEventListener("mousemove", showBar, { passive: true });
  showBar();

  // Lecture bloquée (son coupé ou en pause) → bouton à cliquer.
  const video = () => document.querySelector("video");
  start.addEventListener("click", () => {
    const v = video();
    if (!v) return;
    if (v.muted) {
      const muteBtn = document.querySelector('[data-a-target="player-mute-unmute-button"]');
      if (muteBtn) muteBtn.click(); else v.muted = false;
    }
    v.volume = volume;
    if (v.paused) {
      const playBtn = document.querySelector('[data-a-target="player-play-pause-button"]');
      if (playBtn) playBtn.click(); else v.play().catch(() => {});
    }
    start.hidden = true;
  });

  let checks = 0;
  const timer = setInterval(() => {
    checks += 1;
    const v = video();
    if (v && v.readyState > 0) {
      const blocked = v.paused || v.muted;
      start.hidden = !blocked;
      if (!blocked) {
        if (Math.abs(v.volume - volume) > 0.01 && checks < 4) v.volume = volume;
      }
    }
    if (checks > 30) clearInterval(timer);
  }, 1000);
})();
