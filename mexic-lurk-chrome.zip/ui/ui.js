/* Aides communes aux pages de l'extension. */
var UI = {
  send(type, extra) {
    return browser.runtime.sendMessage(Object.assign({ type }, extra || {}));
  },

  $(sel, root) {
    return (root || document).querySelector(sel);
  },

  thumb(url, w, h) {
    if (!url) return "";
    return url.replace("{width}", w).replace("{height}", h) + "?t=" + Math.floor(Date.now() / 60000);
  },

  duration(since) {
    if (!since) return "";
    const min = Math.max(1, Math.round((Date.now() - since) / 60000));
    if (min < 60) return min + " min";
    const h = Math.floor(min / 60), m = min % 60;
    return h + " h" + (m ? " " + String(m).padStart(2, "0") : "");
  },

  /* Remplit le bandeau « Abonnement fini : me réabonner ». */
  wireResub(el, state, inPlace) {
    if (!el) return;
    el.classList.toggle("hidden", !state.showResub);
    UI.$(".go", el).onclick = () => UI.send("resub", { inPlace });
    UI.$(".close", el).onclick = async () => {
      el.classList.add("hidden");
      await UI.send("dismissResub");
    };
  }
};

document.addEventListener("error", e => {
  if (e.target && e.target.tagName === "IMG") e.target.classList.add("broken");
}, true);

/* Ajuste la hauteur de la fenêtre au contenu (le bas de la fenêtre reste au même endroit). */
UI.fitWindow = async function () {
  try {
    await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
    const win = await browser.windows.getCurrent();
    const chrome = Math.max(0, window.outerHeight - window.innerHeight);
    const wanted = Math.ceil(document.documentElement.scrollHeight + chrome);
    if (!win.height || Math.abs(win.height - wanted) < 4) return;
    const patch = { height: wanted };
    if (win.top != null) patch.top = Math.max(0, win.top + win.height - wanted);
    await browser.windows.update(win.id, patch);
  } catch (e) { /* taille gérée par le système */ }
};
