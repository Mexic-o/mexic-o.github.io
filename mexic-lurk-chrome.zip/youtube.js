(async () => {
  const state = await UI.send("getState");
  const video = state.ytPending;
  if (!video) { window.close(); return; }
  UI.$("#vtitle").textContent = video.title || "";
  if (video.thumb) UI.$("#thumb").src = video.thumb;
  UI.fitWindow();

  const lock = () => document.querySelectorAll("button").forEach(b => { b.disabled = true; });
  UI.$("#watch").onclick = () => { lock(); UI.send("ytWatch"); };
  UI.$("#mini").onclick = () => { lock(); UI.send("ytMini"); };
  UI.$("#later").onclick = () => { lock(); UI.send("ytLater"); };
})();
