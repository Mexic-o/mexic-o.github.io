(async () => {
  UI.$("#settings").onclick = () => { browser.runtime.openOptionsPage(); window.close(); };
  UI.$("#connect").onclick = () => { browser.runtime.openOptionsPage(); window.close(); };

  const render = state => {
    ["connect", "offline", "live"].forEach(v => UI.$("#view-" + v).classList.add("hidden"));
    if (!state.connected) { UI.$("#view-connect").classList.remove("hidden"); return; }
    if (!state.live) {
      UI.$("#channel").href = "https://www.twitch.tv/" + state.channelName.toLowerCase();
      UI.$("#view-offline").classList.remove("hidden");
      return;
    }
    UI.$("#view-live").classList.remove("hidden");
    UI.$("#title").textContent = state.live.title || "";
    UI.$("#game").textContent = state.live.game || "";
    UI.$("#game").classList.toggle("hidden", !state.live.game);
    UI.$("#thumb").src = UI.thumb(state.live.thumbnail, 640, 360);

    const lurking = !!state.lurkStartedAt;
    UI.$("#lurking").classList.toggle("hidden", !lurking);
    UI.$("#join").classList.toggle("hidden", lurking);
    if (lurking) UI.$("#lurking-text").textContent = "Tu es en lurk depuis " + UI.duration(state.lurkStartedAt);

    UI.wireResub(UI.$("#resub"), state, false);
  };

  // Affichage immédiat avec l'état connu, puis actualisation auprès de Twitch.
  render(await UI.send("getState"));
  render(await UI.send("getState", { refresh: true }));

  UI.$("#lurk").onclick = async () => { await UI.send("lurk"); window.close(); };
  UI.$("#show-lurk").onclick = async () => { await UI.send("lurk"); window.close(); };
  UI.$("#live").onclick = async () => { await UI.send("live"); window.close(); };
})();
