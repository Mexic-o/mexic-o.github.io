(async () => {
  const state = await UI.send("getState");
  UI.$("#message").value = state.settings.reminderMessage || "Je lurk encore ♥";
  if (state.lurkStartedAt) {
    UI.$("#since").textContent = "Tu lurkes depuis " + UI.duration(state.lurkStartedAt) + ". Un petit message pour dire que tu es là ?";
  }

  UI.fitWindow();

  UI.$("#later").onclick = () => UI.send("reminderLater");

  const send = async () => {
    const message = UI.$("#message").value.trim();
    if (!message) return;
    const btn = UI.$("#send");
    btn.disabled = true;
    btn.textContent = "Envoi…";
    const res = await UI.send("sendReminder", { message });
    if (!res || !res.ok) {
      btn.disabled = false;
      btn.textContent = "Envoyer";
      const err = UI.$("#error");
      err.textContent = "Pas envoyé : " + ((res && res.error) || "erreur inconnue");
      err.classList.remove("hidden");
      UI.fitWindow();
    }
  };
  UI.$("#send").onclick = send;
  UI.$("#message").addEventListener("keydown", e => { if (e.key === "Enter") send(); });
})();
